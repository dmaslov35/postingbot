import ast, pathlib
p=pathlib.Path(__file__).parent
for name in ('vk_queue_worker_adapter.py','vk_worker_production.py'):
 s=(p/name).read_text(encoding='utf-8'); ast.parse(s)
 assert 'VKBOT_CREATE_TEST_QUEUE_ID' in s
 assert 'VKBOT_CREATE_TEST_GROUP' in s
 assert 'production.stop' in s
assert 'CREATE_ENABLED = False' in (p/'vk_queue_worker_adapter.py').read_text()
print('PASS: static safety checks; CREATE remains OFF')
