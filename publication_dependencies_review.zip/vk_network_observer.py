
"""Безопасный наблюдатель сетевых ответов VK.

Не отправляет запросы и не подтверждает авторство публикаций.
"""

from urllib.parse import urlparse


class VKNetworkObserver:
    def __init__(
        self,
        expected_owner_id=None,
        expected_text=None,
        queue_id=None,
        account_id=None,
    ):
        self.queue_id = queue_id
        self.account_id = account_id
        self.events = []
        self.active_requests = set()
        self.expected_owner_id = expected_owner_id
        self.expected_text = expected_text

    def handle_request(self, request):
        try:
            parsed = urlparse(request.url)
            if (
                parsed.scheme != "https"
                or (parsed.hostname or "").lower() != "api.vk.com"
                or parsed.path.rstrip("/") != "/method/wall.post"
                or request.method.upper() != "POST"
            ):
                return
            if self.expected_owner_id is None or not isinstance(self.expected_text, str):
                return

            from vk_request_matcher import match_wall_post_request

            match = match_wall_post_request(
                request,
                self.expected_owner_id,
                self.expected_text,
            )

            if not match["matched"]:
                return

            self.active_requests.add(request)
        except Exception:
            pass

    def handle_response(self, response):
        try:
            parsed = urlparse(response.url)

            host = (parsed.hostname or "").lower()

            if host not in (
                "vk.com",
                "www.vk.com",
                "vk.ru",
                "www.vk.ru",
                "api.vk.com",
            ):
                return

            request = response.request

            if request not in self.active_requests:
                return
            self.active_requests.discard(request)

            if request.method.upper() != "POST":
                return

            status = int(response.status)

            # Не сохраняем URL, параметры запроса,
            # заголовки, тело запроса или ответа.
            event = {
                "host": host,
                "method": "POST",
                "http_status": status,
                "response_ok": 200 <= status < 300,
                "publication_verified": False,
            }

            # Разбираем только точный метод VK API wall.post.
            # Другие ответы не читаем.
            if (
                host == "api.vk.com"
                and parsed.scheme == "https"
                and parsed.path.rstrip("/") == "/method/wall.post"
                and status == 200
            ):
                from vk_post_response_parser import parse_wall_post_response

                payload = response.json()

                parsed_post = parse_wall_post_response(
                    response.url,
                    request.method,
                    status,
                    payload
                )

                if parsed_post["post_id"] is not None:
                    event["post_id"] = parsed_post["post_id"]
                    event["post_id_source"] = "VK_API_WALL_POST"
                    event["publication_verified"] = False

            self.events.append(event)

        except Exception:
            # Наблюдатель не должен прерывать работу браузера.
            return

    def summary(self):
        return {
            "responses_seen": len(self.events),
            "publication_verified": False,
        }
