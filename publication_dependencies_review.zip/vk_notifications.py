"""Безопасная подготовка уведомлений Telegram.

Модуль не отправляет сообщения самостоятельно.
Для отправки необходим отдельный явный вызов.
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

ALLOWED_EVENTS = {'DELETE_COMPLETED', 'PUBLICATION_CONFIRMED', 'DELETE_FAILED', 'SERVICE_ERROR', 'PUBLICATION_FAILED', 'VK_AUTH_REQUIRED', 'DELETE_REVIEW_REQUIRED', 'PUBLICATION_REVIEW'}

EVENT_TITLES = {'PUBLICATION_REVIEW': 'Публикация требует проверки', 'PUBLICATION_CONFIRMED': 'Публикация подтверждена', 'PUBLICATION_FAILED': 'Ошибка публикации', 'VK_AUTH_REQUIRED': 'Требуется авторизация VK', 'DELETE_COMPLETED': 'Объявление удалено', 'DELETE_FAILED': 'Ошибка удаления', 'SERVICE_ERROR': 'Ошибка работы бота', 'DELETE_REVIEW_REQUIRED': 'Требуется проверка удаления'}


def build_notification(event, details=""):
    """Формирует русскоязычное уведомление."""

    if event not in ALLOWED_EVENTS:
        raise ValueError("Неизвестный тип уведомления")

    title = EVENT_TITLES[event]
    timestamp = datetime.now(
        timezone.utc
    ).strftime("%d.%m.%Y %H:%M UTC")

    message = f"🔔 {title}\n🕒 {timestamp}"

    if details:
        message += f"\n\n{str(details)[:1500]}"

    return message


def notification_record(event, details=""):
    """Создаёт запись для последующей доставки."""

    return {
        "event": event,
        "message": build_notification(event, details),
        "created_at": datetime.now(
            timezone.utc
        ).isoformat(),
        "delivered": False,
    }


# Очередь событий не отправляет сообщения самостоятельно.
# Доставка подключается отдельно.
DEFAULT_QUEUE_DB = Path(__file__).resolve().parent / "runtime" / "notifications.sqlite3"


def _connect_queue(db_path=None):
    import sqlite3

    path = Path(db_path) if db_path is not None else DEFAULT_QUEUE_DB
    path.parent.mkdir(parents=True, exist_ok=True)

    db = sqlite3.connect(str(path), timeout=10)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=10000")
    db.execute("""
        CREATE TABLE IF NOT EXISTS notification_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event TEXT NOT NULL,
            message TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING'
                CHECK(status IN ('PENDING','SENT')),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            sent_at TEXT
        )
    """)
    return db


def enqueue_notification(event, details="", db_path=None):
    """Добавляет уведомление в очередь без отправки."""
    message = build_notification(event, details)

    with _connect_queue(db_path) as db:
        cursor = db.execute(
            "INSERT INTO notification_queue (event, message) VALUES (?, ?)",
            (event, message)
        )
        return cursor.lastrowid


def pending_notifications(limit=20, db_path=None):
    """Возвращает ожидающие уведомления."""
    limit = max(1, min(int(limit), 100))

    with _connect_queue(db_path) as db:
        rows = db.execute(
            """
            SELECT id, event, message, created_at
            FROM notification_queue
            WHERE status='PENDING'
            ORDER BY id
            LIMIT ?
            """,
            (limit,)
        ).fetchall()
        return [dict(row) for row in rows]


def mark_notification_sent(notification_id, db_path=None):
    """Помечает уведомление доставленным только после подтверждения отправки."""
    with _connect_queue(db_path) as db:
        cursor = db.execute(
            """
            UPDATE notification_queue
            SET status='SENT', sent_at=CURRENT_TIMESTAMP
            WHERE id=? AND status='PENDING'
            """,
            (notification_id,)
        )
        return cursor.rowcount == 1
