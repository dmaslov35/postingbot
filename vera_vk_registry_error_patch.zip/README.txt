SAFE PATCH 1: expose publication registry write errors in queue status.
Changes ONLY vk_queue_dispatcher.py; no production enabled, no deletion.
The installer requires runtime/production.stop and matching SHA256, creates a backup,
and does not restart services. Review code before installation.
This is a narrow correctness fix, NOT full autonomous publishing.
