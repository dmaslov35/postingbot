from pathlib import Path
import hashlib,os,datetime,ast
base=Path('/opt/vkbot');stop=base/'runtime/production.stop'
target=base/'vk_queue_dispatcher.py';package=Path(__file__).resolve().parent
assert stop.is_file(), 'STOP_FILE_MISSING'
current=target.read_bytes()
assert hashlib.sha256(current).hexdigest()=='d3dbfa3ded5b20bf77f47adf59231010553f010bbae94ac46726c047b7d81166', 'VERSION_MISMATCH_NO_CHANGE'
data=(package/'patched_vk_queue_dispatcher.py').read_bytes()
ast.parse(data.decode('utf-8'))
backup=base/'runtime'/('vk_queue_dispatcher.py.backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
with backup.open('xb') as f: f.write(current)
os.chmod(backup,0o600)
tmp=target.with_name(target.name+'.patch_tmp')
with tmp.open('xb') as f: f.write(data)
os.chmod(tmp,target.stat().st_mode & 0o777)
assert stop.is_file(), 'STOP_REMOVED_BEFORE_REPLACE'
os.replace(tmp,target)
print('PATCH_INSTALLED; BACKUP:',backup)
print('PRODUCTION_STOP:', 'PRESENT' if stop.is_file() else 'MISSING')
print('NO SERVICES RESTARTED; NO VK ACTIONS')
