import ast
from pathlib import Path
s=Path('patched_vk_queue_dispatcher.py').read_text(encoding='utf-8')
ast.parse(s)
assert 'PUBLICATION_REGISTRY_ERROR:' in s
assert 'PUBLICATION_NOT_VERIFIED_ON_WALL' in s
assert "'REVIEW_REQUIRED'" in s
print('PASS: syntax and review-status preservation')
